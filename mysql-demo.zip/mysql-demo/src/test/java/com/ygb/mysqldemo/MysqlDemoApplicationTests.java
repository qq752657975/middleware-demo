package com.ygb.mysqldemo;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ygb.mysqldemo.mapper.*;
import com.ygb.mysqldemo.pojo.*;
import com.ygb.mysqldemo.service.BalanceService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@SpringBootTest
@Slf4j
class MysqlDemoApplicationTests {

   @Autowired
   private BalanceService balanceService;

   @Autowired
   private RedEnvelopeMapper redEnvelopeMapper;

   @Autowired
   private RedEnvelopeReceiveMapper redEnvelopeReceiveMapper;

   @Autowired
   private UmsMemberBalanceMapper umsMemberBalanceMapper;

   @Autowired
   private UmsMemberMapper umsMemberMapper;

   @Autowired
   private MemberMoneyMapper memberMoneyMapper;

   @Autowired
   private DebtMoneyMapper debtMoneyMapper;

   @Autowired
   private UmsMemberRunningMapper umsMemberRunningMapper;

    @Test
    void contextLoads() {
        List<RedEnvelopeEntity> redEnvelopeEntities =
                redEnvelopeMapper.selectList(Wrappers.<RedEnvelopeEntity>lambdaQuery().between(RedEnvelopeEntity::getCreatedTime, "2022-08-02 00:00:00", "2022-08-02 23:59:59")
                        .gt(RedEnvelopeEntity::getRedBalance, 0));

        for (RedEnvelopeEntity redEnvelopeEntity : redEnvelopeEntities) {
            //查询领取记录
            List<RedEnvelopeReceiveEntity> redEnvelopeReceiveEntities =
                    redEnvelopeReceiveMapper.selectList(Wrappers.<RedEnvelopeReceiveEntity>lambdaQuery().eq(RedEnvelopeReceiveEntity::getRedEnvelopeId, redEnvelopeEntity.getRedEnvelopeId()));

            //判断领取记录是否比红包剩余数多
            if(redEnvelopeReceiveEntities.size() > redEnvelopeEntity.getRedReceiveSize()){

                //判断领取记录是否已经领取全部红包
                if(redEnvelopeReceiveEntities.size() == redEnvelopeEntity.getRedEnvelopeSize()){
                    //声明剩余钱
                    long receiveMoney = 0L;
                    for (RedEnvelopeReceiveEntity redEnvelopeReceiveEntity : redEnvelopeReceiveEntities) {
                        receiveMoney += redEnvelopeReceiveEntity.getRedEnvelopeMoney();
                    }
                    //判断领取总金额是否等于红包发送总金额
                    if(receiveMoney == redEnvelopeEntity.getRedEnvelopeMoney()){
                        log.error("红包主键:{},多余金额:{}",redEnvelopeEntity.getRedEnvelopeId(),redEnvelopeEntity.getRedBalance());
                        Long redBalance = redEnvelopeEntity.getRedBalance();

                        //查询用户信息
                        UmsMember umsMember =
                                umsMemberMapper.selectById(redEnvelopeEntity.getRedEnvelopeMemberSendId());

                        //查询用户余额
                        UmsMemberBalance umsMemberBalance =
                                umsMemberBalanceMapper.selectById(redEnvelopeEntity.getRedEnvelopeMemberSendId());
                        if(umsMemberBalance.getMemberMoney() - redEnvelopeEntity.getRedBalance() > 0){
                            umsMemberBalance.setMemberMoney(umsMemberBalance.getMemberMoney() - redEnvelopeEntity.getRedBalance());
                            //修改用户余额
                            if(!umsMemberBalance.updateById()){
                                throw new RuntimeException("余额修改失败");
                            }
                            redEnvelopeEntity.setRedReceiveSize(redEnvelopeReceiveEntities.size());
                            redEnvelopeEntity.setRedBalance(0L);

                            //修改红包信息
                            if (!redEnvelopeEntity.updateById()) {
                                throw new RuntimeException("红包修改失败");
                            }

                            //记录用户余额
                            MemberMoney memberMoney = memberMoneyMapper.selectById(umsMember.getMemberId());
                            if(ObjectUtil.isNull(memberMoney)){
                                memberMoney = new MemberMoney();
                                memberMoney.setMemberId(umsMember.getMemberId());
                                memberMoney.setMemberAccount(umsMember.getMemberAccount());
                                memberMoney.setMemberNick(umsMember.getMemberNick());
                                memberMoney.setMemberPhone(umsMember.getMemberPhone());
                                memberMoney.setMoney(redBalance);

                                //新增记录余额
                                if(!memberMoney.insert()){
                                    throw new RuntimeException("新增记录余额失败");
                                }
                            }else {
                                //修改记录余额
                                memberMoney.setMoney(memberMoney.getMoney() + receiveMoney);
                                if(!memberMoney.updateById()){
                                    throw new RuntimeException("修改记录余额失败");
                                }
                            }
                        }else{
                            DebtMoney debtMoney = new DebtMoney();
                            debtMoney.setMoney(redBalance);
                            debtMoney.setRedId(redEnvelopeEntity.getRedEnvelopeId());
                            debtMoney.setMemberId(umsMemberBalance.getMemberId());
                            if(!debtMoney.insert()){
                                throw new RuntimeException("新增欠债记录失败");
                            }
                        }

                    }

                }


            }
        }
    }

    @Test
    void test(){

        //获取红包退回流水数据
        List<UmsMemberRunningWater> UmsMemberRunningWaters =
                umsMemberRunningMapper.selectList(Wrappers.<UmsMemberRunningWater>lambdaQuery().likeRight(UmsMemberRunningWater::getRunningOrderNumber, "XGRB").between(UmsMemberRunningWater::getCreatedTime, "2022-08-03 00:00:00", "2022-08-03 23:59:59"));


        long moneySum = 0L;
        int count = 0;
        for (UmsMemberRunningWater umsMemberRunningWater : UmsMemberRunningWaters) {
            log.error("----------------------------------------------------");
            log.error("流水主键:{}",umsMemberRunningWater.getMemberRunningWaterId());
            //截取前缀
            String substring = umsMemberRunningWater.getRunningOrderNumber().substring(4);
            //查询红包信息
            RedEnvelopeEntity redEnvelopeEntity = redEnvelopeMapper.selectById(Long.valueOf(substring));
            log.error("红包主键:{}",redEnvelopeEntity.getRedEnvelopeId());
            //查询红包领取信息
            List<RedEnvelopeReceiveEntity> redEnvelopeReceiveEntities =
                    redEnvelopeReceiveMapper.selectList(Wrappers.<RedEnvelopeReceiveEntity>lambdaQuery().eq(RedEnvelopeReceiveEntity::getRedEnvelopeId, Long.valueOf(substring)));
            log.error("领取记录数量:{}",redEnvelopeReceiveEntities.size());
            //判断领取记录是否比红包剩余数多
            if(CollUtil.isNotEmpty(redEnvelopeReceiveEntities) ){
                log.error("红包领取总数:{},红包被领取总数:{}",redEnvelopeReceiveEntities.size(),redEnvelopeEntity.getRedReceiveSize());
                if(redEnvelopeReceiveEntities.size() > redEnvelopeEntity.getRedReceiveSize()) {

                    //判断领取记录是否已经领取全部红包
                    if (redEnvelopeReceiveEntities.size() == redEnvelopeEntity.getRedEnvelopeSize()) {

                        //声明剩余钱
                        long receiveMoney = 0L;
                        for (RedEnvelopeReceiveEntity redEnvelopeReceiveEntity : redEnvelopeReceiveEntities) {
                            receiveMoney += redEnvelopeReceiveEntity.getRedEnvelopeMoney();
                        }

                        //判断红包剩余
                        if (receiveMoney == redEnvelopeEntity.getRedEnvelopeMoney()) {
                            Long redBalance = umsMemberRunningWater.getRunningWaterMoney() - (redEnvelopeEntity.getRedEnvelopeMoney() - receiveMoney );
                            log.error("红包主键:{},多余金额:{}", redEnvelopeEntity.getRedEnvelopeId(),redBalance);
                            moneySum += receiveMoney;
                            count++;

                            //查询用户信息
                            UmsMember umsMember =
                                    umsMemberMapper.selectById(redEnvelopeEntity.getRedEnvelopeMemberSendId());

                            //查询用户余额
                            UmsMemberBalance umsMemberBalance =
                                    umsMemberBalanceMapper.selectById(redEnvelopeEntity.getRedEnvelopeMemberSendId());
                            if(umsMemberBalance.getMemberMoney() - redBalance> 0){
                                umsMemberBalance.setMemberMoney(umsMemberBalance.getMemberMoney() - redBalance);
                                //修改用户余额
                                if(!umsMemberBalance.updateById()){
                                    throw new RuntimeException("余额修改失败");
                                }
                                redEnvelopeEntity.setRedReceiveSize(redEnvelopeReceiveEntities.size());
                                redEnvelopeEntity.setRedBalance(0L);

                                //修改红包信息
                                if (!redEnvelopeEntity.updateById()) {
                                    throw new RuntimeException("红包修改失败");
                                }

                                //记录用户余额
                                MemberMoney memberMoney = memberMoneyMapper.selectById(umsMember.getMemberId());
                                if(ObjectUtil.isNull(memberMoney)){
                                    memberMoney = new MemberMoney();
                                    memberMoney.setMemberId(umsMember.getMemberId());
                                    memberMoney.setMemberAccount(umsMember.getMemberAccount());
                                    memberMoney.setMemberNick(umsMember.getMemberNick());
                                    memberMoney.setMemberPhone(umsMember.getMemberPhone());
                                    memberMoney.setMoney(redBalance);

                                    //新增记录余额
                                    if(!memberMoney.insert()){
                                        throw new RuntimeException("新增记录余额失败");
                                    }
                                }else {
                                    //修改记录余额
                                    memberMoney.setMoney(memberMoney.getMoney() + receiveMoney);
                                    if(!memberMoney.updateById()){
                                        throw new RuntimeException("修改记录余额失败");
                                    }
                                }
                            }else{
                                DebtMoney debtMoney = new DebtMoney();
                                debtMoney.setMoney(redBalance);
                                debtMoney.setRedId(redEnvelopeEntity.getRedEnvelopeId());
                                debtMoney.setMemberId(umsMemberBalance.getMemberId());
                                debtMoney.setMemberAccount(umsMember.getMemberAccount());
                                debtMoney.setMemberNick(umsMember.getMemberNick());
                                debtMoney.setMemberPhone(umsMember.getMemberPhone());
                                if(!debtMoney.insert()){
                                    throw new RuntimeException("新增欠债记录失败");
                                }
                            }
                        }
                    }
                }
            }

        }

        log.error("红包数据混乱总条数:{},红包混乱总金额:{}",count,moneySum);
    }

}
