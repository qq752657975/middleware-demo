package com.ygb.mysqldemo.pojo;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户流水实体类
 * @author yang
 * @version 1.0
 * @date 2021/7/21 2:23 下午
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@TableName("ums_member_running_water")
public class UmsMemberRunningWater extends Model<UmsMemberRunningWater> implements Serializable {

    private static final long serialVersionUID = 9137948199481820190L;
    @TableId(type = IdType.ASSIGN_ID)
    private Long memberRunningWaterId ;
    /** 交易单号 */
    private String runningOrderNumber ;
    /** 用户id */
    private Long memberId ;
    /** 支付方式;0,充值、1,红包、2,转账、3,订单、4,提现、5,红包过期、6,退货 */
    private Integer runningWaterPayWay ;
    /** 金额 */
    private Long runningWaterMoney ;
    /** 支付类型;0,收入、1,支出 */
    private Integer runningWaterPayType ;
    /** 接收人(如果是收入则是发送方,如果是支付则是接收方) */
    private Long runningWaterReceive ;
    /** 接收人名 */
    private String runningWaterReceiveName ;
    /** 逻辑删除;0,删除、1,不删除 */
    private Integer deleteFlag ;
    /** 创建人 */
    private Long createdBy ;
    /** 创建时间 */
    private Date createdTime ;
}
