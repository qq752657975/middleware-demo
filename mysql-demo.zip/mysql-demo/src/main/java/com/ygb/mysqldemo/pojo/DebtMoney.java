package com.ygb.mysqldemo.pojo;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * TODO
 *
 * @Author ygb
 * @Version 1.0
 * @Date 2022/8/3 14:46
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("debt_money")
public class DebtMoney extends Model<DebtMoney> implements Serializable {

    private Long redId;

    private Long money;

    private Long memberId;

    private String memberPhone;

    private String memberNick;

    private String memberAccount;
}
