package com.ygb.mysqldemo.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ygb.mysqldemo.pojo.UmsMemberRunning;
import com.ygb.mysqldemo.pojo.UmsMemberRunningWater;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 用户流水mapper接口定义
 * @author yang
 * @version 1.0
 * @date 2021/10/13 4:12 下午
 */
@Mapper
public interface RunningWaterMapper extends BaseMapper<UmsMemberRunning> {

}
