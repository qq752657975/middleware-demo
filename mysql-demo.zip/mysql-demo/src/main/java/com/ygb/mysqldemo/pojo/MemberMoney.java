package com.ygb.mysqldemo.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 *
 *
 * @Author ygb
 * @Version 1.0
 * @Date 2022/8/3 14:10
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("member_money")
public class MemberMoney extends Model<MemberMoney> implements Serializable {

    @TableId(type = IdType.ASSIGN_ID)
    private Long memberId;

    private String memberNick;

    private String memberPhone;

    private String memberAccount;

    private Long money;
}
