package com.ygb.mysqldemo.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ygb.mysqldemo.pojo.RedEnvelopeEntity;
import com.ygb.mysqldemo.pojo.RedEnvelopeReceiveEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 红包领取记录表
 * 
 * @author tgh
 * @date 2021-07-14 16:32:26
 */
@Mapper
public interface RedEnvelopeReceiveMapper extends BaseMapper<RedEnvelopeReceiveEntity> {


}
