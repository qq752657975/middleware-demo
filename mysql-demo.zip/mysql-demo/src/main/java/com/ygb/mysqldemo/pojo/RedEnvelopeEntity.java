package com.ygb.mysqldemo.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 红包记录表
 * 
 * @author tgh
 * @date 2021-07-14 15:25:33
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("red_envelope")
public class RedEnvelopeEntity extends Model<RedEnvelopeEntity> implements Serializable {

	private static final long serialVersionUID = -7959722806017587997L;
	/**
	 * 红包记录主键
	 */
	@TableId(type = IdType.ASSIGN_ID)
	private Long redEnvelopeId;
	/**
	 * 红包总金额
	 */
	private Long redEnvelopeMoney;
	/**
	 * 红包单金额(适用于普通多人红包)
	 */
	private Long redEnvelopeSingleMoney;
	/**
	 * 红包主题
	 */
	private String redEnvelopeTopic;
	/**
	 * 发送人
	 */
	private Long redEnvelopeMemberSendId;
	/**
	 * 红包个数
	 */
	private Integer redEnvelopeSize;
	/**
	 * 红包类型 0,拼手气、1,普通多人红包、2,专属、3,单人
	 */
	private Integer redEnvelopeType;
	/**
	 * 接收人
	 */
	private Long redEnvelopeMemberReceiveId;
	/**
	 * 接收群
	 */
	private Long redEnvelopeTalkGroupId;
	/**
	 * 逻辑删除 0,删除、1,不删除
	 */
	private Integer deleteFlag;
	/**
	 * 乐观锁
	 */
	@Version
	private Integer revision;
	/**
	 * 创建人
	 */
	private Long createdBy;
	/**
	 * 创建时间
	 */
	private Date createdTime;
	/**
	 * 更新人
	 */
	private Long updateBy;
	/**
	 * 更新时间
	 */
	private Date updateTime;

	/**
	 * 支付状态(0,未支付,1已支付,2已取消)
	 */
	private Integer redStatus;

	/**
	 * 领取状态(0,未接收,1已接收,2,已过期)
	 */
	private Integer redTakeStatus;

	/**
	 * 红包封面类型
	 */
	private Integer redEnvelopeCoverType;

	/**
	 * 被领取个数
	 */
	private Integer redReceiveSize;

	/**
	 * 剩余金额
	 */
	private Long redBalance;
}
