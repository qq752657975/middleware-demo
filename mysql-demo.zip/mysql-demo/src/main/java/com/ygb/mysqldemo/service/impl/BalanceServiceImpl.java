package com.ygb.mysqldemo.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ygb.mysqldemo.mapper.RedEnvelopeMapper;
import com.ygb.mysqldemo.pojo.RedEnvelopeEntity;
import com.ygb.mysqldemo.service.BalanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 *
 *
 * @Author ygb
 * @Version 1.0
 * @Date 2022/8/3 13:41
 */
@Service
public class BalanceServiceImpl implements BalanceService {

    @Autowired
    private RedEnvelopeMapper redEnvelopeMapper;


    @Override
    @Transactional(rollbackFor = Exception.class)
    public void demo() {
        List<RedEnvelopeEntity> redEnvelopeEntities =
                redEnvelopeMapper.selectList(Wrappers.<RedEnvelopeEntity>lambdaQuery().between(RedEnvelopeEntity::getCreatedTime, "2022-08-01 00:00:00", "2022-08-01 23:59:59")
                        .ge(RedEnvelopeEntity::getRedBalance, 0));


        System.out.println(redEnvelopeEntities);
    }

    @Override
    public void test() {

    }
}
