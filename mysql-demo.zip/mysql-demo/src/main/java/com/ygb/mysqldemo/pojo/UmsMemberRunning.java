package com.ygb.mysqldemo.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * TODO
 *
 * @Author ygb
 * @Version 1.0
 * @Date 2022/8/3 16:44
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("ums_member_running")
@Builder
public class UmsMemberRunning extends Model<UmsMemberRunningWater> implements Serializable {

    private static final long serialVersionUID = 9137948199481820190L;
    @TableId(type = IdType.ASSIGN_ID)
    private Long memberRunningWaterId ;
    /** 交易单号 */
    private String runningOrderNumber ;
    /** 用户id */
    private Long memberId ;
    /** 支付方式;0,充值、1,红包、2,转账、3,订单、4,提现、5,红包过期、6,退货 */
    private Integer runningWaterPayWay ;
    /** 金额 */
    private Long runningWaterMoney ;
    /** 支付类型;0,收入、1,支出 */
    private Integer runningWaterPayType ;
    /** 接收人(如果是收入则是发送方,如果是支付则是接收方) */
    private Long runningWaterReceive ;
    /** 接收人名 */
    private String runningWaterReceiveName ;
    /** 逻辑删除;0,删除、1,不删除 */
    private Integer deleteFlag ;
    /** 创建人 */
    private Long createdBy ;
    /** 创建时间 */
    private Date createdTime ;
}
