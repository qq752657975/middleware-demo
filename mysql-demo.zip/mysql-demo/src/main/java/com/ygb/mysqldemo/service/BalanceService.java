package com.ygb.mysqldemo.service;

/**
 * TODO
 *
 * @Author ygb
 * @Version 1.0
 * @Date 2022/8/3 13:41
 */
public interface BalanceService {


    void demo();

    void test();
}
