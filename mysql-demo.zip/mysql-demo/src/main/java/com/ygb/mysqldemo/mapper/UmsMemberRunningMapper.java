package com.ygb.mysqldemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ygb.mysqldemo.pojo.UmsMemberRunningWater;
import org.apache.ibatis.annotations.Mapper;

/**
 * TODO
 *
 * @Author ygb
 * @Version 1.0
 * @Date 2022/8/3 16:45
 */
@Mapper
public interface UmsMemberRunningMapper extends BaseMapper<UmsMemberRunningWater> {

}
