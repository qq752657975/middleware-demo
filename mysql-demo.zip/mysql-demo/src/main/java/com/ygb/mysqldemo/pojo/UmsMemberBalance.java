package com.ygb.mysqldemo.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户余额实体类
 * @author yang
 * @version 1.0
 * @date 2021/7/21 2:14 下午
 */
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("ums_member_balance")

public class UmsMemberBalance extends Model<UmsMemberBalance> implements Serializable {
    private static final long serialVersionUID = -5933609695256987630L;

    @TableId(type = IdType.ASSIGN_ID)
    private Long memberId ;
    /** 用户余额 */
    private Long memberMoney ;
    /** 逻辑删除;0,删除、1,不删除 */
    private Integer deleteFlag ;
    /** 乐观锁 */
    @Version
    private Integer revision ;
    /** 创建人 */
    private Long createdBy ;
    /** 创建时间 */
    private Date createdTime ;
    /** 更新人 */
    private Long updateBy ;
    /** 更新时间 */
    private Date updateTime ;
}
