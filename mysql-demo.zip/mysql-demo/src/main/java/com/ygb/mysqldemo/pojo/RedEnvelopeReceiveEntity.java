package com.ygb.mysqldemo.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 红包领取记录表
 * 
 * @author tgh
 * @date 2021-07-14 15:25:33
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("red_envelope_receive")
public class RedEnvelopeReceiveEntity implements Serializable {

	private static final long serialVersionUID = 5618775496565970908L;
	/**
	 * 红包领取记录主键
	 */
	@TableId(type = IdType.ASSIGN_ID)
	private Long redEnvelopeReceiveId;
	/**
	 * 红包主键
	 */
	private Long redEnvelopeId;
	/**
	 * 红包接收人
	 */
	private Long redEnvelopeMemberReceiveId;
	/**
	 * 接收金额
	 */
	private Long redEnvelopeMoney;
	/**
	 * 创建人
	 */
	private Long createdBy;
	/**
	 * 创建时间
	 */
	private Date createdTime;

}
