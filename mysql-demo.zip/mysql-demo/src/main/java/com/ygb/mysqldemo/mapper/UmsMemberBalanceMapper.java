package com.ygb.mysqldemo.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ygb.mysqldemo.pojo.UmsMemberBalance;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @author yang
 * @version 1.0
 * @date 2021/8/17 4:52 下午
 */
@Mapper
public interface UmsMemberBalanceMapper extends BaseMapper<UmsMemberBalance> {


}
