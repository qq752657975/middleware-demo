package com.ygb.mysqldemo.mapper;



import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ygb.mysqldemo.pojo.RedEnvelopeEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


/**
 * @Author tgh
 * @Date 2021/8/9 14:57
 * @Version 1.0
 */
@Mapper
public interface RedEnvelopeMapper extends BaseMapper<RedEnvelopeEntity> {




}
